'''
    Temporal cliques: Enumerating delta-cliques in temporal graphs. 
    Copyright (C) 2016 Anne-Sophie Himmel
    For licensing see COPYING.
'''

class Clique:

	def __init__(self, V, I):
		(start, end) = I;
		self.R = frozenset(V);
		self.startInterval = start;
		self.endInterval = end;

	def __eq__(self, other):
		return self.R == other.R and self.startInterval == other.startInterval and self.endInterval == other.endInterval

	def __hash__(self):
		return hash((self.R,self.startInterval, self.endInterval))

	def __str__(self):
		return "{"+','.join(map(str, list(self.R))) + "} (" + str(self.startInterval) + "," + str(self.endInterval)+")"

	def expandClique(self, v, I):
		(start, end) = I
		self.R |= frozenset([v])
		if start <= end:
			self.startInterval = start
			self.endInterval = end

	def expandCliqueByVertex(self, v):
		self.R |= frozenset([v])

	def size(self):
                return len(self.R)
		  
