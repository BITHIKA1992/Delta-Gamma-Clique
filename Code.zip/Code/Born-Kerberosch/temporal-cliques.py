#! /usr/bin/env python

'''
    Temporal cliques: Enumerating delta-cliques in temporal graphs. 
    Copyright (C) 2016 Anne-Sophie Himmel

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from CliqueMaster import CliqueMaster
from Neighborhood import Neighborhood
from Clique import Clique
import sys, time
import optparse
import resource
import csv
import os
import psutil

import networkx as nx
import bisect



def main():

    usage = "Usage: cat <temporal graph> | ./temporal-cliques.py [options]"
    fmt = optparse.IndentedHelpFormatter(max_help_position=50, width=100)

    parser = optparse.OptionParser(usage=usage, formatter=fmt)
    
    parser.add_option("-d", "--delta", type="int", dest="delta", default=0,
                      help="Delta, default is 0.")
    parser.add_option("-p", "--pivoting", type="int", dest="pivoting_lvl", default=0,
                      help="Set the algorithm used for pivoting by setting PIVOTING_LVL to one of the following. "
                      "0: Do not use pivoting. "
                      "1: Pick a single arbitrary pivot. "
                      "2: Pick a single pivot maximizing the number of removed elements. "
                      "3: Pick an arbitrary maximal set of pivots. "
                      "4: Pick a set of pivots greedily according to the maximum number of removed elements. "
                      "5: Pick a set of pivots maximizing the number of removed elements.")
    parser.add_option("-s", "--statistics-file", metavar="FILE", type="string", dest="statistics_file", default=None,
                      help="Output computation statistics into FILE.")
    parser.add_option("-c", "--clique-file", metavar="FILE", type="string", dest="clique_file", default=None,
                      help="Output enumerated cliques into FILE.")

    (options, args) = parser.parse_args()

    delta = options.delta
    
    t_min = float('inf')
    t_max = 0
    times = dict()
    vertices = set()
    Grph = nx.Graph()
    t1 = time.time()
    # Read temporal graph
    for line in sys.stdin:
        contents = line.split()
        t = int(contents[0])
        u = contents[1]
        v = contents[2]

        if u == v:
            print(sys.stderr, "Ignoring self-loop on vertex " + u + " at time " + str(t), file=sys.stderr)
            continue

        edge = frozenset([u, v])
        Grph.add_edge(str(u), str(v))

        # Populate data structures
        if edge not in times: times[edge] = []
        times[edge].append(t)
        if u not in vertices: vertices.add(u)
        if v not in vertices: vertices.add(v)

        t_min = min(t_min, t)
        t_max = max(t_max, t)

    # Start execution
    sys.stdout.write("First Edge: %d \n" % (t_min))
    sys.stdout.write("Last Edge: %d \n" % (t_max))
    sys.stdout.write("# vertices = %d \n" % (len(vertices)))
    amount = 0
    for i in times.keys():
        amount += len(times[i])
    sys.stdout.write("# timestamps = %d \n" % (amount))
    sys.stdout.write("# delta = %d \n " % (delta)) 
    #t1 = time.time()
    C = CliqueMaster(times, vertices, t_min-delta, t_max+delta, delta, options.pivoting_lvl)
    t2 = time.time()
    sys.stdout.write("Accumulated time to calculate Cliques: %s seconds \n" % (t2 - t1))
    sys.stdout.write("# maximal Delta-Cliques: %d \n" % (len(C.maxCliques)))
    sys.stdout.write("max Clique Size: %d \n" % (C.maxCliqueSize()))
    _result_list = C.finalMaximalCliques()  ## added by Bithika
    process = psutil.Process(os.getpid())
    print("Used Memory: ", process.memory_info().rss/1024/1024, "MB")  # in bytes 

    

    if options.statistics_file is not None:
        statistics_list = [t2 - t1, resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1000, C.callCounter, len(C.maxCliques), C.maxCliqueSize(), C.average_clique_size(), C.max_clique_length(), C.average_clique_length()]
        with open(options.statistics_file, "w+") as statf:
            wrtr = csv.writer(statf)
            wrtr.writerows([statistics_list])

    if options.clique_file is not None:
        with open(options.clique_file, "w+") as cliquef:
            print(str(C), file=cliquef)

if __name__ == "__main__":
    sys.exit(main())
