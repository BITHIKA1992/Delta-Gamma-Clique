from CliqueMaster import CliqueMaster
from Clique import Clique
import sys
import time as TM
import os
import psutil

import networkx as nx
import bisect


# Initiate
Cm = CliqueMaster()
times = dict()
nodes = dict()
nb_lines = 0
resurrect = False

# Read arguments from command line
if len(sys.argv) == 2:
    delta = int(sys.argv[1])
else:
    sys.stderr.write(
        "Usage: cat <stream> | python main.py <int:delta>\
        \n\n")
    sys.exit(1)

if delta < 0:
    sys.stderr.write("Delta must be positive.\n")
    sys.exit(1)

# Create Graph
G = nx.Graph()

start_time = TM.time()

# Read stream
for line in sys.stdin:
    contents = line.split(" ")
    t = int(contents[0])
    u = contents[1].strip()
    v = contents[2].strip()

    link = frozenset([u, v])
    time = (t, t)

    ##Add the edge in the static graph G
    G.add_edge(str(u), str(v))

    # This a new instance
    Cm.addClique(Clique((link, time), set([])))

    # Populate data structures
    if link not in times:
        times[link] = []
    times[link].append(t)

    if u not in nodes:
        nodes[u] = set()

    if v not in nodes:
        nodes[v] = set()

    nodes[u].add(v)
    nodes[v].add(u)
    nb_lines = nb_lines + 1
Cm._times = times
Cm._nodes = nodes
#sys.stderr.write("Processed " + str(nb_lines) + " from stdin\n")

# Restart execution
R = Cm.getDeltaCliques(delta)

end_time = TM.time()


if len(Cm._R) > 0: 
    print("Number of cliques: ", str(len(Cm._R)) )
    print("Delta: ", str(delta) )
    print("Max cardinality: ", str(Cm._maxsize))
    print("Max duration: ", str(Cm._maxdur))
    print("Number of iterations: ", str(Cm._iternum))
    print("Computational Time: ", end_time - start_time)
    process = psutil.Process(os.getpid())
    print("Used Memory: ", process.memory_info().rss/1024/1024, "MB")  # in bytes 
#    with open("test_m.txt", "a") as myfile:
#		write_X= str(len(Cm._R)) + " | " + str(delta) + " | " + str(gamma) + " | "  + str(Cm._maxsize) + " | " + str(Cm._iternum)  + " | " + str(Cm._maxdur) + "\n"
#		myfile.write(write_X)

#sys.stdout.write("# delta = %d\n" % (delta))
#Cm.printCliques()
#Cm.printCliquesDistribution(delta)
