from CliqueMaster_2 import CliqueMaster
from Clique_2 import Clique
import sys
import networkx as nx
import bisect
import time as TM
import os
import psutil



# Initiate
Cm = CliqueMaster()
times = dict()
nodes = dict()
nb_lines = 0
resurrect = False

# Read arguments from command line
if len(sys.argv) == 3:
    delta = int(sys.argv[1])
    gamma = int(sys.argv[2])
    dt = 1
else:
    sys.stderr.write(
        "Usage: cat <stream> | python main.py <int:delta> <int:gamma>\
        \n\n")
    sys.exit(1)

if delta < 0:
    sys.stderr.write("Delta must be positive.\n")
    sys.exit(1)
    
if gamma < 0:
    sys.stderr.write("Gamma must be positive.\n")
    sys.exit(1)

# Create Graph
G = nx.Graph()
# Read stream
start_time = TM.time()
for line in sys.stdin:
    contents = line.split(" ")
    t = int(contents[0])
    u = contents[1].strip()
    v = contents[2].strip()

    link = frozenset([u, v])
    time = (t, t)
    
    ##Add the edge in the static graph G
    G.add_edge(str(u), str(v))

    # This a new instance
    #Cm.addClique(Clique((link, time), set([])))

    # Populate data structures
    if link not in times:
        times[link] = []
    if t not in times[link]:
        times[link].append(t)

    if u not in nodes:
        nodes[u] = set()

    if v not in nodes:
        nodes[v] = set()

    nodes[u].add(v)
    nodes[v].add(u)
    nb_lines = nb_lines + 1
Cm._times = times
Cm._nodes = nodes
Cm._graph = G
sys.stderr.write("Processed " + str(nb_lines) + " from stdin\n")

#print(G.edges())

##### Bithika:

for e in G.edges():
	#print(e[0],e[1])
	link = frozenset([e[0], e[1]])
	X = set([e[0],e[1]])
	Y = set(list(G.neighbors(e[0])))
	Z = set(list(G.neighbors(e[1])))
	neighborlist = (Y.intersection(Z))-X
	temp_ts = times[frozenset([e[0],e[1]])]
	temp_ts.sort()
	if len(temp_ts) >= gamma:
            for i in range(len(temp_ts) - gamma +1):
                if (temp_ts[i + gamma-1] - temp_ts[i]) == delta:
                    tb = temp_ts[i]
                    te = temp_ts[i + gamma-1]
                    time = (tb, te)
                    Cm.addClique(Clique((link, time), neighborlist))
                elif (temp_ts[i + gamma-1] - temp_ts[i]) < delta:
                    tb = temp_ts[i]
                    te = temp_ts[i + gamma-1]
                    time1 = (te-delta, te)
                    time2 = (tb, tb + delta)	
                    Cm.addClique(Clique((link, time1), neighborlist))
                    Cm.addClique(Clique((link, time2), neighborlist))
		


#Cm.printInitialCliques()
Cm.getDeltaGammaCliques(delta, gamma, dt)		
#Cm.printCliques()

end_time = TM.time()

if len(Cm._R) > 0: 
	print("Number of cliques: ", str(len(Cm._R)) )
	print("Delta: ", str(delta) )
	print("Max cardinality: ", str(Cm._maxsize))
	print("Max duration: ", str(Cm._maxdur))
	print("Number of iterations: ", str(Cm._iternum))
	print("Computational Time: ", end_time - start_time)
	process = psutil.Process(os.getpid())
	print("Used Memory:", process.memory_info().rss/1024/1024, "MB")  # in bytes 


# Restart execution
#R = Cm.getDeltaCliques(delta)
#sys.stdout.write("# delta = %d\n" % (delta))
#Cm.printCliques()


#Cm.printCliquesDistribution(delta)
